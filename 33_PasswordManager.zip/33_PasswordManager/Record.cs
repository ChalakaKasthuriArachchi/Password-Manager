﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _33_PasswordManager
{
    [Serializable]
    public sealed class Record
    {
        public Record(string aID,string aName,string anURL,string aUserName,string aPassword)
        {
            ID = int.Parse(aID);
            Name = aName;
            URL = anURL;
            UserName = aUserName;
            Password = aPassword;
        }
        public int ID;
        public string Name;
        public string URL;
        public string UserName;
        public string Password;
    }
}
